//
//  TrackingDashboardView.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//

import SwiftUI

struct TrackingDashboardView: View {
    var body: some View {
        VStack {
            Text("Tracking Dashboard")
                .font(Theme.Typography.titleFont)
            
            Text("Track your product availability here")
                .font(Theme.Typography.bodyFont)
        }
        .navigationTitle("Tracking")
    }
}

#Preview {
    TrackingDashboardView()
}
