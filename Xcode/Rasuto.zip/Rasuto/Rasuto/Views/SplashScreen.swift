//
//  SplashScreen.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//

import SwiftUI

struct SplashScreen: View {
    @State private var isActive = false
    @AppStorage("hasSeenSplash") private var hasSeenSplash = false
    
    var body: some View {
        ZStack {
            if isActive || hasSeenSplash {
                MainView()
            } else {
                VStack {
                    Text("Rasuto")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                    
                    // Add your logo or animation here
                    Image(systemName: "bag.fill")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, height: 100)
                        .foregroundColor(.blue)
                }
                .onAppear {
                    // Simulate a delay
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
                        withAnimation {
                            self.isActive = true
                            self.hasSeenSplash = true
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    SplashScreen()
}
