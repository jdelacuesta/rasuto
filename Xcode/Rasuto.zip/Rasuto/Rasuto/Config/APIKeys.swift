//
//  APIKeys.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//

import Foundation

enum APIKeys {
    // This is a placeholder - you'll need to replace these with actual API keys
    // DO NOT commit this file to git
    static let bestBuyAPIKey = "YOUR_BEST_BUY_API_KEY"
    static let targetAPIKey = "YOUR_TARGET_API_KEY"
    // Add other API keys as needed
}
