//
//  MainView.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            NavigationView {
                ProductListView()
            }
            .tabItem {
                Label("Home", systemImage: "house")
            }
            
            NavigationView {
                TrackingDashboardView()
            }
            .tabItem {
                Label("Track", systemImage: "chart.line.uptrend.xyaxis")
            }
            
            Text("Add Item")
                .font(.largeTitle)
                .tabItem {
                    Label("Add", systemImage: "plus.circle.fill")
                }
            
            NavigationView {
                NotificationsView()
            }
            .tabItem {
                Label("Alerts", systemImage: "bell")
            }
            
            NavigationView {
                SettingsView()
            }
            .tabItem {
                Label("Settings", systemImage: "gear")
            }
        }
    }
}

#Preview {
    MainView()
}
