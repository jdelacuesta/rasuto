//
//  ProductListView.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//

import SwiftUI

struct ProductListView: View {
    var body: some View {
        List {
            Text("Product 1")
            Text("Product 2")
            Text("Product 3")
        }
        .navigationTitle("Products")
    }
}

#Preview {
    ProductListView()
}
