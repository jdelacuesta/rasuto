//
//  Products.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//

import Foundation
import SwiftData

@Model
final class Product {
    var id: UUID
    var name: String
    var url: URL?
    var imageURL: URL?
    var price: Double?
    var currency: String?
    var isInStock: Bool
    var retailer: String
    var addedDate: Date
    var lastChecked: Date?
    
    init(name: String, url: URL? = nil, imageURL: URL? = nil, price: Double? = nil, currency: String? = "USD", isInStock: Bool = true, retailer: String) {
        self.id = UUID()
        self.name = name
        self.url = url
        self.imageURL = imageURL
        self.price = price
        self.currency = currency
        self.isInStock = isInStock
        self.retailer = retailer
        self.addedDate = Date()
        self.lastChecked = Date()
    }
}
