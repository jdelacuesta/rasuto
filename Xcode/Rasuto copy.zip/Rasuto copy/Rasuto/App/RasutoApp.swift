//
//  RasutoApp.swift
//  Rasuto
//
//  Created by JC Dela Cuesta on 4/14/25.
//
import SwiftUI
import SwiftData

@main
struct RasutoApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            if let container = ModelContainerManager.shared.container {
                SplashScreen()
                    .modelContainer(container)
            } else {
                Text("Failed to load data container.")
            }
        }
    }
}
